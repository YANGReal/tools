#!/bin/sh

./testC /Volumes/Data/Users/dhoerl/Development/xlslib/svn/trunk/xlslib/targets/test
./testCPP /Volumes/Data/Users/dhoerl/Development/xlslib/svn/trunk/xlslib/targets/test
./PR2859188 /Volumes/Data/Users/dhoerl/Development/xlslib/svn/trunk/xlslib/targets/test
./PR3076678 /Volumes/Data/Users/dhoerl/Development/xlslib/svn/trunk/xlslib/targets/test




