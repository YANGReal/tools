//
//  main.m
//  iExcel
//
//  Created by YANGRui on 14-4-16.
//  Copyright (c) 2014年 YANGReal. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "YRAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YRAppDelegate class]));
    }
}
