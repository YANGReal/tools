//
//  YRAppDelegate.m
//  iExcel
//
//  Created by YANGRui on 14-4-16.
//  Copyright (c) 2014年 YANGReal. All rights reserved.
//


#define DOCUMENTPATH [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
#define TMPPATH NSTemporaryDirectory()
#define CACHPATH [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0]
#define CACH_DOCUMENTS_PATH(fileName) [CACHPATH stringByAppendingPathComponent:fileName]//缓存文件路径
#define DOCUMENTS_PATH(fileName) [DOCUMENTPATH stringByAppendingPathComponent:fileName]//Documents文件夹路径



#import "YRAppDelegate.h"
#import <JXLS/JXLSWorkBook.h>
@implementation YRAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    [self myTest];
    return YES;
}



- (void)myTest
{
    
    NSArray *array = @[@"编号",@"姓名",@"年龄",@"性别",@"身份证号"];
    
    
    NSMutableDictionary *dict1 = [NSMutableDictionary dictionary];
    [dict1 setObject:@"001" forKey:@0];
    [dict1 setObject:@"张三" forKey:@1];
    [dict1 setObject:@"21" forKey:@2];
    [dict1 setObject:@"男" forKey:@3];
    [dict1 setObject:@"222222222222222222" forKey:@4];
    
    NSMutableDictionary *dict2 = [NSMutableDictionary dictionary];
    [dict2 setObject:@"002" forKey:@0];
    [dict2 setObject:@"哈哈" forKey:@1];
    [dict2 setObject:@"25" forKey:@2];
    [dict2 setObject:@"男" forKey:@3];
    [dict2 setObject:@"111111111111111111" forKey:@4];

    NSMutableDictionary *dict3 = [NSMutableDictionary dictionary];
    [dict3 setObject:@"003" forKey:@0];
    [dict3 setObject:@"李四" forKey:@1];
    [dict3 setObject:@"21" forKey:@2];
    [dict3 setObject:@"男" forKey:@3];
    [dict3 setObject:@"333333333333333333" forKey:@4];

    NSMutableDictionary *dict4 = [NSMutableDictionary dictionary];
    [dict4 setObject:@"004" forKey:@0];
    [dict4 setObject:@"王五" forKey:@1];
    [dict4 setObject:@"22" forKey:@2];
    [dict4 setObject:@"男" forKey:@3];
    [dict4 setObject:@"444444444444444444" forKey:@4];

    NSMutableDictionary *dict5 = [NSMutableDictionary dictionary];
    [dict5 setObject:@"005" forKey:@0];
    [dict5 setObject:@"王二麻子" forKey:@1];
    [dict5 setObject:@"20" forKey:@2];
    [dict5 setObject:@"男" forKey:@3];
    [dict5 setObject:@"555555555555555555" forKey:@4];
    
    NSArray *data = @[dict1,dict2,dict3,dict4,dict5];
    
	NSString *filePath = DOCUMENTS_PATH(@"123.xls");
	
	JXLSCell				*cell;
    
	JXLSWorkBook *workBook = [JXLSWorkBook new];
	
	JXLSWorkSheet *workSheet = [workBook workSheetWithName:@"SHEET1"];
	
	//[workSheet setHeight:100 forRow:1 defaultFormat:NULL];
	[workSheet setWidth:1000 forColumn:0 defaultFormat:NULL];
    [workSheet setWidth:5000 forColumn:4 defaultFormat:NULL];
	
    for (int i = 0;i<array.count;i++)
    {
        cell = [workSheet setCellAtRow:0 column:i toString:array[i]];
        [cell setHorizontalAlignment:HALIGN_CENTER];
		[cell setIndentation:INDENT_0];
    }
    
    for (int i = 0;i<data.count;i++)
    {
        NSDictionary *dict = data[i];
        for (int j = 0;j<5;j++)
        {
            cell = [workSheet setCellAtRow:i+1 column:j toString:[dict objectForKey:@(j)]];
            [cell setHorizontalAlignment:HALIGN_CENTER];
            [cell setIndentation:INDENT_0];
        }
    }
    
    int fud = [workBook writeToFile:filePath];
	
	NSLog(@"OK - bye! fud=%d", fud);

    return;
    /*
	for(uint32_t idx=0; idx<10; ++idx)
    {
		cell = [workSheet setCellAtRow:idx column:0 toString:[NSString stringWithFormat:@"Row %d", idx + 1]];
		if(idx & 1) {
			// prove we can get the cell reference later
			cell = [workSheet cellAtRow:idx col:0];
		}
		[cell setHorizontalAlignment:HALIGN_LEFT];
		[cell setIndentation:INDENT_0];
	}
    //	[workSheet mergeCellsInRect:(NSRect){{10, 10}, {3, 3}}];
	
    //	NSData *now = [NSDate date];
    //	NSDate *then = [NSDate dateWithString:@"1899-01-01 12:00:00 +0000").
	
	for(uint32_t idx=0; idx<10; ++idx) {
		[workSheet setCellAtRow:idx column:1 toDoubleValue:3.1415f withNumberFormat:FMT_GENERAL + idx];
	}
    
	[workSheet setWidth:30000 forColumn:2 defaultFormat:NULL];
	for(uint32_t idx=0; idx<7; ++idx) {
		cell = [workSheet setCellAtRow:idx column:2 toString:@"Hello"];
		[cell setHorizontalAlignment:HALIGN_GENERAL + idx];
	}
    
	[workSheet setWidth:0xFFFF forColumn:3 defaultFormat:NULL];
	for(uint32_t idx=0; idx<4; ++idx) {
		[workSheet setHeight:24 forRow:idx defaultFormat:NULL];
		cell = [workSheet setCellAtRow:idx column:3 toString:@" World"];
		[cell setVerticalAlignment:VALIGN_TOP + idx];
	}
	
	//int fud = [workBook writeToFile:filePath];
	
	NSLog(@"OK - bye! fud=%d", fud);
     */
}





- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
